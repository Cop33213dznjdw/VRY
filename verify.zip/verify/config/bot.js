module.exports = {
    discord: {
        token: 'OTQyMzQyNzc2NDg0NDAxMjMy.YgjHGQ.XlCegttpuMVn8aW7AP3mkrAefeQ', //TOKEN HERE
        prefix: '.' //CUSTOMS
    },
};