const { MessageEmbed } = require("discord.js");
const ms = require("ms");
module.exports = {
    name: 'verify',
    aliases: ['vfy'],
    category: 'info',
    execute(client, message, args) {
			function Code(length) {
				var result           = '';
				var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
				var charactersLength = characters.length;
				for ( var i = 0; i < length; i++ ) {
				  result += characters.charAt(Math.floor(Math.random() * 
			 charactersLength));
			   }
			   return result;
			}

			const code = Code(30)
			message.channel.send('เช็คที่แชทส่วนตัวของคุณ !')
			message.author.send("นำคีย์ในไปใส่ในช่อง ", new MessageEmbed()  
			.setTitle(""+ code +"")
			.setColor('GREEN')).then(() => {
			 const filter = (m) => {    return m.author.id === message.author.id; };
				message.channel.awaitMessages(filter, { max: 1, time: 100000, errors: ['time'] })
					.then(collected => {
					  if(collected.first().content === code) {
						 message.author.send(new MessageEmbed()
			.setTitle(':white_check_mark: Success!')
			.setDescription("```ยินดีด้วยคุณผ่านแล้วว```")
			.setColor('GREEN')).then((msg) => {
			  
			  let person = message.guild.member
			  let mainRole = message.guild.roles.cache.get(`942347005634707476`);
			  message.member.roles.add(mainRole.id);
			  if(message.member.roles.cache.has(mainRole.id)) {
				console.log(`Yay, the author of the message has the role!`);
			  } else {
				console.log(`Nope, noppers, nadda.`);
			  }
			})
					  } else {
						message.author.send(new MessageEmbed()
			.setTitle(':x: Error!')
			.setDescription("```คุณใส่รหัสไม่ถูกต้องกรุณาทำใหม่```")
			.setColor('RED')).then((msg) => {
				msg.react('❌')
			})
					}
					})
					.catch(collected => {
						message.author.send(new MessageEmbed()
			.setTitle(':x: Error!')
			.setDescription("```คุณใช้เวลานานเกินไป กรุณาทำคำสั่งใหม่```")
			.setColor(RED)).then((msg) => {
				msg.react('❌')
			})
					});
			}); 
  }
}